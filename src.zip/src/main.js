import React , {useEffect,useState} from 'react';
import logo from './logo.png';
import './App.css';
import Loader from './Loader';
import SubPage from './SubPage';

function Welcome() {
    const [loading,setLoading]=useState(true);


   useEffect(() =>{
     setTimeout(() => {
        setLoading(false);
        document.body.style.background = 'white'
     },5000);
     console.log("ok");
   
   },[]);

    return (
        
        <>{
        loading?
        <div style={{background:"black"}}>
        <div className='Head' >
        <img src={logo} alt="Logo" height="200px"/>
        <div>Welcome To Domino's</div>
        </div>
        <div className="MainText">ORDER</div>
        <div className='SubText'>YOUR PIZZA</div>
         <div className='load'><Loader></Loader></div>
        </div>:<div className='App'>
            <SubPage></SubPage></div>}
        </>
      );
    
}

export default Welcome;
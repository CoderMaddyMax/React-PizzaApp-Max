
import './App.css';
import Welcome from './main';


function App() {
    return (<div  >
<Welcome></Welcome>
        </div>


    );
}

export default App;
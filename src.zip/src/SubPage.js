import React  , {useEffect,useState} from 'react';
import logo from './logo.png';
import Pizza from './pizzas.jpg';
import Menu from './menu.png';
import './SubPage.css';
import {EnglishTrans,FrenchTrans} from './translation.js'


function SubPage (){
    const [showDropdown,setShowDropdown]=useState('dropdown-content');
    const [data,setData]=useState(EnglishTrans);
    function clickedOnMenu(){
        console.log('TEXT');
        showDropdown=='dropdown-content'?setShowDropdown('dropdown-content show'):setShowDropdown('dropdown-content');
    }
    function selectOption(e){
        
        if(e.target.name=='English'){
            setData(EnglishTrans);
        }
        else{
            setData(FrenchTrans);
        }
        setShowDropdown('dropdown-content')
    }
    return(
        <>
        <div className='pizza-order'>
        <div className='orderPage'>
        <img src={logo} className='logo-domino' alt="Logo" height="4rem"/>
        <div className='drop-list'>
        <img src={Menu} className='logo-menu' onClick={clickedOnMenu} alt="Logo" height="4rem"/><br/>
        
        <div id="myDropdown" className={showDropdown}>
        <a href="#" name='English' onClick={selectOption}>English</a>
        <a href="#" name='French' onClick={selectOption}>French</a>
        </div> </div>
        </div>



        
        <div className='logo-pizza pizza-title'>
            {data.text5}
        </div>
        <div className='logo-pizza'>
        <img src={Pizza} className='pizza-img' alt="pizza" height="200px"/>
        </div>
        <div className='logo-pizza pizzaName'>
            {data.text1}
        </div>
        <div className='logo-pizza pizzaSub'>
        {data.text2} <br/>
        {data.text3}
        </div>
        <div className='logo-pizza bottomText'>
        {data.text4}
        </div>
        </div>
        </>

    );

}

export default SubPage;
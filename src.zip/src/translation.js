export const EnglishTrans={
    text1:"VEG PIZZA 8'",
    text2:'veg cheessy toppings' ,
    text3:'firewood baked pizza',
    text4:'Fast Delivery Yummy Food , voila!!!',
    text5:'Pizza'
}

export const FrenchTrans={
    text1:"VEG PIZA 8'",
    text2:'veg cheessy top' ,
    text3:'firewood baked pza',
    text4:'Fast Dvery my Food , voila!!!',
    text5:'Pizza'
}

